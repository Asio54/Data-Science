#drop missing values
import pandas as pd
#original dataframe
data = {
    "student":["amina","brian","cathy","derrick","edna"],
    "age":[21,None, 23, 22, None],
    "gpa":[3.0, 3.2, None, 3.5, 3.1]
}
df = pd.DataFrame(data)
#drop rows with missing values
df_drop = df.dropna()
#display resulting dataframe
print(df_drop)

#fill with mean or median
#fill missing age with mean age
mean_age = df['age'].mean()
df['age'].fillna(mean_age, inplace=True)

#fill missing gpa with median gpa
median_gpa = df['gpa'].median()
df["gpa"].fillna(median_gpa, inplace=True)

#print dataframe
print(df)

#exercise 2.2.1: detect outliers
import pandas as pd
df = pd.DataFrame({
     "Salary": [4000, 4200, 4100, 80000, 4300, 4150]
     })

#calculate Q1,Q3 and IQR
Q1 = df['Salary'].quantile(0.25)
Q3 = df['Salary'].quantile(0.75)
IQR = Q3 - Q1

#define bounds
lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR

#detect outliers
outliers = df[(df["Salary"]<lower) | (df["Salary"]>upper)]
print(outliers)

#exercise 2.2.2: correct implausible values
df = pd.DataFrame({
    "Age":[25, 30, -5, 1000, 40]
})
#calculate median of valid age
valid = df[(df["Age"]>=0) & (df["Age"]<=120)]
median_age = valid["Age"].median()
#replace invalid ages
df["Age"] = df["Age"].apply(lambda x: median_age if x < 0 or x > 120 else x)
print(df)

#exercise 2.2.3: format correction
import numpy as np
df = pd.DataFrame({
    "Age":["25", "30", "Twenty-Five", "45", "32"]
})
#convert numeric, invalid to NaN
df["Age"] = pd.to_numeric(df["Age"], errors='coerce')
print(df)

#exercise 2.3.1: normalise values
import pandas as pd
df = pd.DataFrame({
    "Income":[20000, 30000, 25000, 40000]
})
df["Normal"] = (df["Income"]-df["Income"].min ())/(df["Income"].max()-df["Income"].min())
print(df)


#exercise 2.3.2:convert age to categories
df = pd.DataFrame({
    "Age":[5, 20, 67, 15, 40, 80]
})
#categorise age
def category(age):
    if age <= 11:
        return "Child"
    elif age <= 59:
        return "Adult"
    else:
        return "Senior"
df["Age_group"] = df["Age"].apply(category)
print(df)


#exercise 2.3.3: simplify large values
df["Income_e"] = df["Income"] / 1000
print(df)